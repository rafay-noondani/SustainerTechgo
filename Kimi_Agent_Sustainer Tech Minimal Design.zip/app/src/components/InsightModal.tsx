import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ArrowRight } from 'lucide-react';

interface Insight {
  title: string;
  excerpt: string;
  content: string;
  image: string;
}

interface InsightModalProps {
  insight: Insight | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function InsightModal({ insight, isOpen, onClose }: InsightModalProps) {
  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  // Close on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [onClose]);

  if (!insight) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-4 md:inset-10 lg:inset-20 z-50 overflow-auto"
          >
            <div className="min-h-full flex items-center justify-center py-8">
              <div 
                className="relative w-full max-w-4xl glass-card rounded-3xl lg:rounded-4xl overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={onClose}
                  className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/10 text-sustainer-text-primary hover:bg-white/20 transition-colors"
                >
                  <X size={24} />
                </button>

                {/* Image */}
                <div className="h-48 md:h-64 lg:h-80 overflow-hidden">
                  <img
                    src={insight.image}
                    alt={insight.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Content */}
                <div className="p-6 md:p-10 lg:p-12">
                  <h2 className="font-heading text-2xl md:text-3xl lg:text-4xl font-bold text-sustainer-text-primary mb-4">
                    {insight.title}
                  </h2>

                  <div className="prose prose-invert max-w-none">
                    <p className="text-sustainer-text-secondary text-base lg:text-lg leading-relaxed whitespace-pre-line">
                      {insight.content}
                    </p>
                  </div>

                  {/* CTA */}
                  <div className="mt-8 pt-6 border-t border-white/10">
                    <a
                      href="#contact"
                      onClick={onClose}
                      className="btn-primary group inline-flex"
                    >
                      Discuss your project
                      <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
