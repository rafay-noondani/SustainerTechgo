import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function AISpotlight() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen bg-sustainer-bg-primary flex items-center py-20">
      {/* Glow Background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(circle at 50% 55%, rgba(45, 107, 255, 0.14), transparent 60%)',
        }}
      />

      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        {/* Spotlight Card */}
        <div className="relative w-full max-w-[86vw] mx-auto min-h-[60vh] lg:min-h-[64vh] glass-card rounded-4xl overflow-hidden flex items-center">
          {/* Content - Left Side */}
          <div className="relative z-10 p-8 lg:p-16 max-w-full lg:max-w-[55%]">
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-sustainer-text-primary leading-[1.05]">
              AI that actually helps users.
            </h2>

            <p className="mt-6 lg:mt-8 text-base lg:text-lg text-sustainer-text-secondary max-w-md">
              We integrate models into real workflows—search, recommendations,
              automation—without losing clarity or trust.
            </p>

            <a
              href="#work"
              className="inline-flex items-center gap-2 mt-6 lg:mt-8 text-sustainer-accent hover:text-white transition-colors text-sm font-medium group"
            >
              Explore AI work
              <ArrowRight
                size={16}
                className="group-hover:translate-x-1 transition-transform"
              />
            </a>
          </div>

          {/* Circular Image - Right Side */}
          <div className="absolute right-[-4vh] lg:right-[-6vh] top-1/2 -translate-y-1/2 w-[30vh] h-[30vh] lg:w-[44vh] lg:h-[44vh] rounded-full overflow-hidden border-2 border-white/10 hidden md:block">
            <img
              src="/images/ai_visualization.jpg"
              alt="AI Visualization"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
