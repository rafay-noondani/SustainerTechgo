import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const metrics = [
  { value: 120, suffix: '%', label: 'Average performance lift', isRange: false },
  { value: 40, suffix: '%', label: 'Reduction in time-to-launch', isRange: false },
  { value: 0, suffix: '', label: '4-10 working days delivery', isRange: true, rangeText: '4-10' },
];

function AnimatedNumber({ value, suffix, isRange, rangeText }: { value: number; suffix: string; isRange?: boolean; rangeText?: string }) {
  const [displayValue, setDisplayValue] = useState(0);
  const hasAnimated = useRef(false);

  if (isRange && rangeText) {
    return <span className="tabular-nums">{rangeText}</span>;
  }

  useEffect(() => {
    if (hasAnimated.current) return;
    
    const trigger = ScrollTrigger.create({
      trigger: '.metrics-container',
      start: 'top 80%',
      onEnter: () => {
        if (hasAnimated.current) return;
        hasAnimated.current = true;
        
        gsap.to(
          { val: 0 },
          {
            val: value,
            duration: 2,
            ease: 'power2.out',
            onUpdate: function () {
              setDisplayValue(Math.round(this.targets()[0].val));
            },
          }
        );
      },
    });

    return () => trigger.kill();
  }, [value]);

  return (
    <span className="tabular-nums">
      {displayValue}
      {suffix}
    </span>
  );
}

export default function MetricsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-[60vh] bg-sustainer-bg-primary flex items-center py-20">
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        <div className="relative w-full max-w-[86vw] mx-auto glass-card rounded-4xl py-16 lg:py-20 flex items-center justify-center">
          <div className="metrics-container grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-16 w-full max-w-4xl px-8 lg:px-16">
            {metrics.map((metric, index) => (
              <div key={index} className="text-center">
                <div className="font-heading text-5xl lg:text-7xl font-bold text-sustainer-accent">
                  <AnimatedNumber 
                    value={metric.value} 
                    suffix={metric.suffix} 
                    isRange={metric.isRange}
                    rangeText={metric.rangeText}
                  />
                </div>
                <p className="mt-3 text-sm lg:text-base text-sustainer-text-secondary">
                  {metric.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
