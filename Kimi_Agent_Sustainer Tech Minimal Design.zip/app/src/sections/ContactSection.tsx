import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, MapPin, Send, Loader2 } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative py-20 lg:py-28 bg-sustainer-bg-secondary"
    >
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        {/* Contact Card */}
        <div className="glass-card rounded-3xl lg:rounded-4xl p-8 lg:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            {/* Left Column - Info */}
            <div>
              <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary">
                Let's build your next product.
              </h2>
              <p className="mt-4 text-sustainer-text-secondary text-base lg:text-lg">
                Tell us what you're making. We'll reply within 48 hours.
              </p>

              <div className="mt-8 lg:mt-12 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-sustainer-accent/10 text-sustainer-accent">
                    <Mail size={20} />
                  </div>
                  <div>
                    <p className="micro-label">Email</p>
                    <a
                      href="mailto:hello@sustainertech.com"
                      className="text-sustainer-text-primary hover:text-sustainer-accent transition-colors"
                    >
                      hello@sustainertech.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-xl bg-sustainer-accent/10 text-sustainer-accent">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <p className="micro-label">Location</p>
                    <p className="text-sustainer-text-primary">Based worldwide</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Form */}
            <div>
              {isSubmitted ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12">
                  <div className="w-16 h-16 rounded-full bg-sustainer-accent/20 flex items-center justify-center mb-4">
                    <Send size={24} className="text-sustainer-accent" />
                  </div>
                  <h3 className="font-heading text-xl font-semibold text-sustainer-text-primary">
                    Message sent!
                  </h3>
                  <p className="mt-2 text-sustainer-text-secondary">
                    We'll get back to you within 48 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label
                      htmlFor="name"
                      className="block text-sm font-medium text-sustainer-text-secondary mb-2"
                    >
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sustainer-text-primary placeholder:text-sustainer-text-secondary/50 focus:outline-none focus:border-sustainer-accent/50 focus:ring-1 focus:ring-sustainer-accent/50 transition-all"
                      placeholder="Your name"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-sustainer-text-secondary mb-2"
                    >
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sustainer-text-primary placeholder:text-sustainer-text-secondary/50 focus:outline-none focus:border-sustainer-accent/50 focus:ring-1 focus:ring-sustainer-accent/50 transition-all"
                      placeholder="you@company.com"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="message"
                      className="block text-sm font-medium text-sustainer-text-secondary mb-2"
                    >
                      Message
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sustainer-text-primary placeholder:text-sustainer-text-secondary/50 focus:outline-none focus:border-sustainer-accent/50 focus:ring-1 focus:ring-sustainer-accent/50 transition-all resize-none"
                      placeholder="Tell us about your project..."
                    />
                  </div>

                  <div>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="btn-primary w-full justify-center disabled:opacity-70 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 size={18} className="animate-spin mr-2" />
                          Sending...
                        </>
                      ) : (
                        <>
                          Send message
                          <Send size={18} className="ml-2" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
