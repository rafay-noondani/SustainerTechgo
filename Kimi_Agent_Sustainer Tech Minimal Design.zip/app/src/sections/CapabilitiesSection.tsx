import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Layers, Smartphone, Brain, Palette, Cloud, Globe, Search } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const capabilities = [
  { icon: Globe, label: 'Web Development' },
  { icon: Smartphone, label: 'Mobile Apps' },
  { icon: Search, label: 'SEO Services' },
  { icon: Layers, label: 'SaaS Platforms' },
  { icon: Brain, label: 'AI Systems' },
  { icon: Palette, label: 'Design Systems' },
  { icon: Cloud, label: 'Cloud Architecture' },
];

export default function CapabilitiesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="relative min-h-screen bg-sustainer-bg-primary flex items-center py-20"
    >
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        <div className="relative w-full max-w-[88vw] mx-auto min-h-[70vh] lg:min-h-[72vh] flex flex-col lg:flex-row gap-6">
          {/* Left Feature Card */}
          <div className="flex-1 lg:w-[44vw] glass-card rounded-3xl lg:rounded-4xl overflow-hidden p-8 lg:p-10">
            {/* Circular Image */}
            <div className="absolute right-[-5%] lg:right-[-10%] top-1/2 -translate-y-1/2 w-[35%] lg:w-[45%] aspect-square rounded-full overflow-hidden opacity-50 hidden md:block">
              <img
                src="/images/capability_portrait.jpg"
                alt="Capabilities"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Content */}
            <div className="relative z-10">
              <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary mb-6 lg:mb-8">
                Capabilities
              </h2>

              <ul className="space-y-3 lg:space-y-4">
                {capabilities.map((cap) => (
                  <li
                    key={cap.label}
                    className="flex items-center gap-3 text-sustainer-text-secondary hover:text-sustainer-text-primary transition-colors cursor-default"
                  >
                    <cap.icon size={18} className="text-sustainer-accent" />
                    <span className="text-sm lg:text-base">{cap.label}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#services"
                className="inline-flex items-center gap-2 mt-6 lg:mt-8 text-sustainer-accent hover:text-white transition-colors text-sm font-medium group"
              >
                See services
                <ArrowRight
                  size={16}
                  className="group-hover:translate-x-1 transition-transform"
                />
              </a>
            </div>
          </div>

          {/* Right Cards */}
          <div className="flex-1 lg:w-[40vw] flex flex-col gap-6">
            {/* Right Top Card */}
            <div className="flex-1 glass-card rounded-3xl overflow-hidden relative group cursor-pointer min-h-[200px]">
              <img
                src="/images/saas_team.jpg"
                alt="SaaS Development"
                className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sustainer-bg-primary/80 to-transparent" />
              <div className="absolute bottom-4 left-4 lg:bottom-6 lg:left-6">
                <span className="micro-label">SaaS</span>
                <p className="text-sustainer-text-primary font-medium mt-1">Web Platforms</p>
              </div>
            </div>

            {/* Right Bottom Card */}
            <div className="flex-1 glass-card rounded-3xl overflow-hidden relative group cursor-pointer min-h-[200px]">
              <img
                src="/images/ai_visualization.jpg"
                alt="AI Solutions"
                className="w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sustainer-bg-primary/80 to-transparent" />
              <div className="absolute bottom-4 left-4 lg:bottom-6 lg:left-6">
                <span className="micro-label">AI / ML</span>
                <p className="text-sustainer-text-primary font-medium mt-1">Intelligent Systems</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
