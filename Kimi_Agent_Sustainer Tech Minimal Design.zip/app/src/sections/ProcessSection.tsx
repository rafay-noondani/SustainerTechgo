import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Search, PenTool, Rocket } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const processSteps = [
  {
    number: '01',
    title: 'Discovery',
    description: 'We map the problem, the users, and the constraints.',
    icon: Search,
  },
  {
    number: '02',
    title: 'Design & Prototype',
    description: 'We build the interface, test it, and refine.',
    icon: PenTool,
  },
  {
    number: '03',
    title: 'Build & Launch',
    description: 'We ship clean code, monitor, and optimize.',
    icon: Rocket,
  },
];

export default function ProcessSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-28 bg-sustainer-bg-primary">
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        <div className="mb-12 lg:mb-16">
          <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary">
            How we work
          </h2>
          <p className="mt-4 text-sustainer-text-secondary max-w-lg text-base lg:text-lg">
            A simple, transparent process designed to reduce risk and keep momentum.
          </p>
        </div>

        <div className="space-y-4 lg:space-y-5">
          {processSteps.map((step) => (
            <div
              key={step.number}
              className="glass-card rounded-2xl lg:rounded-3xl p-6 lg:p-8 flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-8 card-hover"
              style={{ maxWidth: '920px' }}
            >
              <span className="micro-label text-sustainer-accent">{step.number}</span>
              <div className="flex-1">
                <h3 className="font-heading text-xl lg:text-2xl font-semibold text-sustainer-text-primary">
                  {step.title}
                </h3>
                <p className="mt-1 text-sustainer-text-secondary text-sm lg:text-base">
                  {step.description}
                </p>
              </div>
              <div className="p-3 rounded-xl bg-sustainer-accent/10 text-sustainer-accent self-start lg:self-center">
                <step.icon size={24} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
