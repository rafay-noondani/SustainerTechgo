import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    name: 'Nova Dashboard',
    tags: 'SaaS / UX',
    image: '/images/case_study_nova.jpg',
  },
  {
    name: 'Orbit Mobile',
    tags: 'iOS / Android',
    image: '/images/case_study_orbit.jpg',
  },
  {
    name: 'Axiom AI',
    tags: 'ML / Search',
    image: '/images/case_study_axiom.jpg',
  },
];

export default function WorkSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="work" className="relative min-h-screen bg-sustainer-bg-primary flex items-center py-20">
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        <div className="relative w-full max-w-[88vw] mx-auto min-h-[70vh] lg:min-h-[72vh] flex flex-col lg:flex-row gap-6">
          {/* Left Tall Card */}
          <div className="lg:w-[30vw] h-[400px] lg:h-auto glass-card rounded-3xl lg:rounded-4xl overflow-hidden group cursor-pointer relative">
            <img
              src={projects[0].image}
              alt={projects[0].name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-sustainer-bg-primary/90 via-sustainer-bg-primary/30 to-transparent" />
            <div className="absolute bottom-6 left-6">
              <span className="micro-label">{projects[0].tags}</span>
              <h3 className="font-heading text-xl lg:text-2xl font-semibold text-sustainer-text-primary mt-2">
                {projects[0].name}
              </h3>
            </div>
          </div>

          {/* Right Cards */}
          <div className="flex-1 lg:w-[54vw] flex flex-col gap-6">
            {/* Right Top Card */}
            <div className="flex-1 h-[200px] lg:h-auto glass-card rounded-3xl overflow-hidden group cursor-pointer relative">
              <img
                src={projects[1].image}
                alt={projects[1].name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sustainer-bg-primary/90 via-sustainer-bg-primary/30 to-transparent" />
              <div className="absolute bottom-4 left-4 lg:bottom-6 lg:left-6">
                <span className="micro-label">{projects[1].tags}</span>
                <h3 className="font-heading text-lg lg:text-xl font-semibold text-sustainer-text-primary mt-1 lg:mt-2">
                  {projects[1].name}
                </h3>
              </div>
            </div>

            {/* Right Bottom Card */}
            <div className="flex-1 h-[200px] lg:h-auto glass-card rounded-3xl overflow-hidden group cursor-pointer relative">
              <img
                src={projects[2].image}
                alt={projects[2].name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-sustainer-bg-primary/90 via-sustainer-bg-primary/30 to-transparent" />
              <div className="absolute bottom-4 left-4 lg:bottom-6 lg:left-6">
                <span className="micro-label">{projects[2].tags}</span>
                <h3 className="font-heading text-lg lg:text-xl font-semibold text-sustainer-text-primary mt-1 lg:mt-2">
                  {projects[2].name}
                </h3>
              </div>
            </div>
          </div>
        </div>

        {/* View All Link */}
        <div className="mt-8 lg:mt-12 text-right">
          <a
            href="#work"
            className="inline-flex items-center gap-2 text-sustainer-accent hover:text-white transition-colors text-sm font-medium group"
          >
            View all case studies
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform"
            />
          </a>
        </div>
      </div>
    </section>
  );
}
