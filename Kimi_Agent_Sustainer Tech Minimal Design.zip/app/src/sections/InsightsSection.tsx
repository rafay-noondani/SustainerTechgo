import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import InsightModal from '../components/InsightModal';

gsap.registerPlugin(ScrollTrigger);

const insights = [
  {
    title: 'Design systems that survive growth',
    excerpt: 'How to build scalable design systems that maintain consistency as your product evolves.',
    content: `Design systems are the backbone of scalable product development. When built correctly, they enable teams to move faster while maintaining consistency across every touchpoint.

The key to a design system that survives growth is modularity. Each component should be self-contained, with clear documentation and usage guidelines. This allows teams to update individual pieces without breaking the entire system.

At Sustainer Tech, we approach design systems with a focus on:

• Component Architecture - Building reusable, composable components that scale
• Documentation - Clear guidelines that help teams use components correctly
• Governance - Processes for reviewing and evolving the system over time
• Accessibility - Ensuring every component meets WCAG standards from day one

We've helped companies like TechFlow and Nova Labs build design systems that have scaled from 10 to 100+ team members without losing consistency. The result? Faster shipping, fewer bugs, and a more cohesive user experience.`
    ,
    image: '/images/insight_01.jpg',
  },
  {
    title: 'Shipping AI without breaking UX',
    excerpt: 'Best practices for integrating AI features while maintaining a seamless user experience.',
    content: `AI is transforming how we build products, but integrating it without disrupting the user experience requires careful consideration.

The biggest mistake we see is treating AI as a black box. Users need transparency - they should understand when AI is being used and how it affects their experience.

Our approach to AI integration focuses on:

• Progressive Disclosure - Starting with simple AI features and gradually increasing complexity
• User Control - Always giving users the ability to override AI decisions
• Feedback Loops - Clear indicators when AI is processing and what it's doing
• Error Handling - Graceful fallbacks when AI doesn't perform as expected

We've implemented AI solutions for search, recommendations, and content generation - always with the user experience as the primary consideration. The result is AI that feels helpful, not intrusive.`
    ,
    image: '/images/insight_02.jpg',
  },
  {
    title: 'Mobile performance myths',
    excerpt: 'Debunking common misconceptions about mobile app performance optimization.',
    content: `Mobile performance is often misunderstood. Let's debunk some common myths:

Myth 1: "Native apps are always faster than cross-platform"
Reality: Modern cross-platform frameworks like React Native can achieve near-native performance when built correctly. The key is understanding the platform's limitations and optimizing accordingly.

Myth 2: "You need to optimize everything"
Reality: Premature optimization is the root of all evil. Focus on the metrics that matter to users - time to interactive, first contentful paint, and smooth scrolling.

Myth 3: "Performance is only about code"
Reality: Images, fonts, and third-party scripts often have a bigger impact than your code. We use techniques like lazy loading, code splitting, and asset optimization to deliver fast experiences.

At Sustainer Tech, we build mobile apps that load in under 3 seconds and maintain 60fps scrolling - regardless of whether they're native or cross-platform.`
    ,
    image: '/images/insight_03.jpg',
  },
];

export default function InsightsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [selectedInsight, setSelectedInsight] = useState<typeof insights[0] | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const openModal = (insight: typeof insights[0]) => {
    setSelectedInsight(insight);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setTimeout(() => setSelectedInsight(null), 300);
  };

  return (
    <>
      <section ref={sectionRef} id="insights" className="relative py-20 lg:py-28 bg-sustainer-bg-primary">
        <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
          <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary mb-12 lg:mb-16">
            Insights
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            {insights.map((insight, index) => (
              <article
                key={index}
                className="glass-card rounded-2xl lg:rounded-3xl overflow-hidden card-hover group cursor-pointer"
              >
                <div className="h-40 lg:h-48 overflow-hidden">
                  <img
                    src={insight.image}
                    alt={insight.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-lg lg:text-xl font-semibold text-sustainer-text-primary group-hover:text-sustainer-accent transition-colors">
                    {insight.title}
                  </h3>
                  <p className="mt-2 text-sustainer-text-secondary text-sm line-clamp-2">
                    {insight.excerpt}
                  </p>
                  <button
                    onClick={() => openModal(insight)}
                    className="inline-flex items-center gap-2 mt-4 text-sustainer-accent hover:text-white transition-colors text-sm font-medium"
                  >
                    Read more
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <InsightModal
        insight={selectedInsight}
        isOpen={isModalOpen}
        onClose={closeModal}
      />
    </>
  );
}
