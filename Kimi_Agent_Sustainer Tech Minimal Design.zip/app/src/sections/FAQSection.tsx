import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: "What's your typical engagement?",
    answer:
      'We typically work on a project basis or retainer model. Projects range from 4-12 weeks for MVPs, to ongoing partnerships for product evolution. We tailor our engagement to your specific needs and timeline.',
  },
  {
    question: 'How fast can you ship an MVP?',
    answer:
      'Most MVPs ship within 4-10 working days for smaller projects, and 2-4 weeks for more complex applications. We follow an agile approach with daily updates, allowing you to see progress and provide feedback throughout the development process.',
  },
  {
    question: 'Do you work with existing teams?',
    answer:
      "Absolutely. We often collaborate with in-house teams, providing specialized expertise in design systems, AI integration, or performance optimization. We're flexible in our approach to fit your team's workflow.",
  },
  {
    question: 'What tech stack do you use?',
    answer:
      'We primarily use React, Next.js, TypeScript, and Node.js for web applications. For mobile, we use React Native or native development. For AI/ML, we work with Python, TensorFlow, and various cloud AI services.',
  },
  {
    question: 'How do you handle maintenance?',
    answer:
      'We offer ongoing maintenance and support packages that include monitoring, bug fixes, security updates, and feature iterations. We ensure your product stays reliable and up-to-date.',
  },
  {
    question: 'Can you help with product strategy?',
    answer:
      "Yes, our discovery phase includes product strategy, user research, and competitive analysis. We help define your product roadmap and ensure you're building the right thing for your users.",
  },
];

function FAQItem({
  question,
  answer,
  isOpen,
  onToggle,
}: {
  question: string;
  answer: string;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="glass-card rounded-2xl overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-5 lg:p-6 text-left"
      >
        <span className="font-heading text-base lg:text-lg font-medium text-sustainer-text-primary pr-4">
          {question}
        </span>
        <ChevronDown
          size={20}
          className={`text-sustainer-accent flex-shrink-0 transition-transform duration-300 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <div className="px-5 lg:px-6 pb-5 lg:pb-6">
          <p className="text-sustainer-text-secondary text-sm lg:text-base leading-relaxed">
            {answer}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function FAQSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} id="faq" className="relative py-20 lg:py-28 bg-sustainer-bg-primary">
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        {/* Heading */}
        <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary mb-12 lg:mb-16">
          FAQ
        </h2>

        {/* FAQ List */}
        <div className="space-y-3 lg:space-y-4 max-w-3xl">
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onToggle={() =>
                setOpenIndex(openIndex === index ? null : index)
              }
            />
          ))}
        </div>
      </div>
    </section>
  );
}
