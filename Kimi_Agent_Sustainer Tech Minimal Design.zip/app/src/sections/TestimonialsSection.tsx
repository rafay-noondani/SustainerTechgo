import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Star } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    quote:
      'Sustainer Tech turned our roadmap into a product in days. Their speed and quality are unmatched.',
    author: 'A. Chen',
    role: 'CTO',
    company: 'TechFlow',
  },
  {
    quote:
      'The team shipped faster than we thought possible. Our users love the new experience.',
    author: 'M. Ross',
    role: 'Product Lead',
    company: 'Nova Labs',
  },
  {
    quote:
      'Our SaaS finally feels modern—and it performs. The ROI has been incredible.',
    author: 'S. Patel',
    role: 'Founder',
    company: 'DataSync',
  },
];

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0.8, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-28 bg-sustainer-bg-primary">
      <div ref={contentRef} className="w-full px-6 lg:px-[6vw]">
        {/* Heading */}
        <h2 className="font-heading text-3xl lg:text-5xl font-bold text-sustainer-text-primary mb-12 lg:mb-16">
          What clients say
        </h2>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="glass-card rounded-2xl lg:rounded-3xl p-6 lg:p-8 card-hover"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={16}
                    className="fill-sustainer-accent text-sustainer-accent"
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-sustainer-text-primary text-base lg:text-lg leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-sustainer-accent/20 flex items-center justify-center">
                  <span className="text-sustainer-accent font-medium text-sm">
                    {testimonial.author.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="text-sustainer-text-primary font-medium text-sm">
                    {testimonial.author}
                  </p>
                  <p className="text-sustainer-text-secondary text-xs">
                    {testimonial.role}, {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
