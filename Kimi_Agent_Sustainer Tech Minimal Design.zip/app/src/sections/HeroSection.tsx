import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ArrowRight } from 'lucide-react';

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const orbitCardRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const smallCardsRef = useRef<HTMLDivElement[]>([]);

  // Simple entrance animation on load only
  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        orbitCardRef.current,
        { scale: 0.92, opacity: 0 },
        { scale: 1, opacity: 1, duration: 0.9, ease: 'power2.out', delay: 0.2 }
      );

      smallCardsRef.current.forEach((card, i) => {
        if (card) {
          gsap.fromTo(
            card,
            { scale: 0.85, opacity: 0 },
            {
              scale: 1,
              opacity: 1,
              duration: 0.8,
              ease: 'power2.out',
              delay: 0.4 + i * 0.08,
            }
          );
        }
      });

      gsap.fromTo(
        textRef.current?.querySelectorAll('.hero-text-item') || [],
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.7,
          ease: 'power2.out',
          stagger: 0.1,
          delay: 0.6,
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const addToSmallCardsRef = (el: HTMLDivElement | null, index: number) => {
    if (el) {
      smallCardsRef.current[index] = el;
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-sustainer-bg-primary flex items-center justify-center py-20"
    >
      <div className="glow-bg" />

      <div
        ref={(el) => addToSmallCardsRef(el, 0)}
        className="absolute left-[10vw] top-[14vh] w-[18vw] h-[22vh] glass-card rounded-3xl animate-float hidden lg:block"
        style={{ animationDelay: '0s' }}
      />
      <div
        ref={(el) => addToSmallCardsRef(el, 1)}
        className="absolute right-[10vw] top-[12vh] w-[18vw] h-[22vh] glass-card rounded-3xl animate-float hidden lg:block"
        style={{ animationDelay: '1.5s' }}
      />
      <div
        ref={(el) => addToSmallCardsRef(el, 2)}
        className="absolute left-[12vw] bottom-[12vh] w-[18vw] h-[22vh] glass-card rounded-3xl animate-float hidden lg:block"
        style={{ animationDelay: '3s' }}
      />
      <div
        ref={(el) => addToSmallCardsRef(el, 3)}
        className="absolute right-[12vw] bottom-[14vh] w-[18vw] h-[22vh] glass-card rounded-3xl animate-float hidden lg:block"
        style={{ animationDelay: '4.5s' }}
      />

      <div
        ref={orbitCardRef}
        className="relative w-[90vw] lg:w-[78vw] min-h-[60vh] lg:min-h-[62vh] glass-card rounded-4xl animate-breathe flex items-center justify-center py-16"
      >
        <div ref={textRef} className="text-center px-6 lg:px-16 max-w-4xl">
          <span className="hero-text-item micro-label block mb-6">
            Sustainer Tech
          </span>

          <h1 className="hero-text-item font-heading text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold text-sustainer-text-primary leading-[0.95] tracking-tight">
            We build digital
            <br />
            products that scale.
          </h1>

          <p className="hero-text-item mt-6 lg:mt-8 text-base lg:text-lg text-sustainer-text-secondary max-w-xl mx-auto">
            Strategy, design, and engineering for SaaS, mobile, and AI.
          </p>

          <div className="hero-text-item mt-8 lg:mt-10">
            <a href="#contact" className="btn-primary group">
              Book a discovery call
              <ArrowRight size={18} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
