import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HeroSection from './sections/HeroSection';
import CapabilitiesSection from './sections/CapabilitiesSection';
import SaaSSpotlight from './sections/SaaSSpotlight';
import MobileSpotlight from './sections/MobileSpotlight';
import AISpotlight from './sections/AISpotlight';
import ProcessSection from './sections/ProcessSection';
import WorkSection from './sections/WorkSection';
import MetricsSection from './sections/MetricsSection';
import TestimonialsSection from './sections/TestimonialsSection';
import InsightsSection from './sections/InsightsSection';
import FAQSection from './sections/FAQSection';
import ContactSection from './sections/ContactSection';

gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    return () => {
      ScrollTrigger.getAll().forEach((st) => st.kill());
    };
  }, []);

  return (
    <div className="relative bg-sustainer-bg-primary min-h-screen">
      {/* Noise Overlay */}
      <div className="noise-overlay" />
      
      {/* Navigation */}
      <Navbar />
      
      {/* Main Content */}
      <main className="relative">
        {/* Section 1: Hero */}
        <HeroSection />
        
        {/* Section 2: Capabilities Mosaic */}
        <CapabilitiesSection />
        
        {/* Section 3: SaaS Spotlight */}
        <SaaSSpotlight />
        
        {/* Section 4: Mobile Spotlight */}
        <MobileSpotlight />
        
        {/* Section 5: AI Spotlight */}
        <AISpotlight />
        
        {/* Section 6: Process */}
        <ProcessSection />
        
        {/* Section 7: Selected Work */}
        <WorkSection />
        
        {/* Section 8: Metrics */}
        <MetricsSection />
        
        {/* Section 9: Testimonials */}
        <TestimonialsSection />
        
        {/* Section 10: Insights */}
        <InsightsSection />
        
        {/* Section 11: FAQ */}
        <FAQSection />
        
        {/* Section 12: Contact */}
        <ContactSection />
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;
